package modelo;

public class IdObligatorioException extends RuntimeException {
    public IdObligatorioException(String message) {
        super(message);
    }
}
